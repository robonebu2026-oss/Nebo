import {Nebo} from '../core/nebo.js';
export const Biblioteca={
  pessoal:()=>Nebo.memoria,   // experiências da própria Nebo
  cidade:[]                   // PONTO DE EXTENSÃO: história dos Nebos, origem (Órion), acontecimentos do mundo
};
