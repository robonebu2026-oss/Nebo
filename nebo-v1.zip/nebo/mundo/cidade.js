// Estrutura da Nébula City. Nenhum local está pronto ainda.
import {Eventos} from '../core/eventos.js';import {Memoria} from '../memoria/memoria.js';
export const LOCAIS=[['praca','Praça','⛲'],['jardim','Jardim','🌿'],['casas','Casas','🏠'],['eventos','Eventos','🎉'],['observatorio','Observatório','🔭'],['museu','Museu','🏛️'],['biblioteca','Biblioteca','📚']].map(([id,nome,icone])=>({id,nome,icone,pronto:false}));
export const Cidade={
  lista:()=>LOCAIS,
  visitar(id){const l=LOCAIS.find(x=>x.id===id);if(!l?.pronto)return;Eventos.emitir('visita',{id,primeira:!Memoria.buscar('visita').some(m=>m.dados.id===id)})}
};
