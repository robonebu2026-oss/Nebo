// Só representa o sentimento escolhido. Sem boca por padrão: só as expressões oficiais que têm.
const E=(x,y,rx,ry,r=0)=>`<ellipse class="o" cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" transform="rotate(${r} ${x} ${y})"/><ellipse class="b" cx="${x-rx*.35}" cy="${y-ry*.4}" rx="${rx*.22}" ry="${ry*.2}" transform="rotate(${r} ${x} ${y})"/>`;
const C=(x,y,w,h)=>`<rect class="o" x="${x-w/2}" y="${y-h/2}" width="${w}" height="${h}" rx="${w/2}"/><rect class="b" x="${x-w/4}" y="${y-h/2+h*.12}" width="${w*.2}" height="${h*.22}" rx="${w*.1}"/>`;
const L=d=>`<path class="l" d="${d}"/>`;
const A=(a,b,h)=>`<path class="o" d="M${a} 66Q${(a+b)/2} ${h} ${b} 56Q${(a+b)/2} 50 ${a} 66Z"/>`;
const S=(x,y)=>{let d=`M${x} ${y}`;for(let t=.5;t<=14;t+=.5)d+=`L${(x+Math.cos(t)*t*1.5).toFixed(1)} ${(y+Math.sin(t)*t*1.5).toFixed(1)}`;return L(d)};
const caret=L('M94 84l6-6 6 6'),u=L('M92 82q8 9 16 0');
const ZZ='<text class="z" x="150" y="34">z</text><text class="z" x="162" y="22" font-size="10">z</text>';
export const EXPRESSOES={
  neutro:C(60,60,24,50)+C(140,60,24,50),
  neutro_deitado:E(58,58,28,15)+E(142,58,28,15)+caret,
  feliz:A(30,90,22)+A(170,110,22)+caret,
  curioso:E(62,58,18,18)+E(138,58,18,18),
  medo:E(62,52,20,22)+E(138,52,20,22)+L('M92 96h16')+L('M26 48l-8-4M174 48l8-4'),
  surpresa:E(70,46,16,22)+E(130,46,16,22)+'<path class="p" d="M84 72h32l-3 24H87z"/>'+L('M42 66l-10-4M158 66l10-4'),
  dormindo:'<path class="o" d="M34 58Q58 76 84 58Q58 64 34 58Z"/><path class="o" d="M116 58Q142 76 166 58Q142 64 116 58Z"/>'+ZZ,
  sono:L('M30 60h50')+L('M120 60h50')+L('M96 80q4 4 8 0')+ZZ,
  descansando:E(58,58,32,9)+E(142,58,32,9)+u,
  irritado:E(58,60,26,15,18)+E(142,60,26,15,-18)+L('M164 30h10M169 25v10'),
  desconfiado:E(58,60,30,10,-10)+E(142,60,30,10,-6),
  preocupado:E(56,58,18,28)+E(142,64,32,11)+L('M66 98l12-6 14-3'),
  triste:E(58,58,28,14,-18)+E(142,58,28,14,18)+caret+'<path class="o" d="M170 84q-6 9 0 14q6-5 0-14z"/>',
  tonta:S(60,58)+S(140,58)+caret,
  afeto:A(30,90,38)+A(170,110,38)+u+L('M100 38C86 28 90 14 100 22C110 14 114 28 100 38Z'),
  afeicao:A(30,90,38)+A(170,110,38)+u+L('M22 100l-6-4M178 100l6-4'),
  doente:E(58,78,40,12,-8)+E(142,78,40,12,8)+L('M94 104l6-6 6 6')+L('M26 100l-8-4M24 108l-8-2M174 100l8-4M176 108l8-2')+'<path class="p" d="M62 44Q50 24 76 22Q90 6 118 18Q148 18 140 40Q120 50 62 44Z"/><rect class="p" x="92" y="6" width="18" height="22" rx="3"/>',
  // Espaços preparados: do catálogo, ainda NÃO reproduzidos (preencher fiel ao original)
  atencao:null,aflicao:null,muito_coracao:null,curioso_lados:null,triste_variacao:null
};
// Sentimento -> expressão do catálogo. Troque aqui se quiser outra.
export const MAPA={neutra:'neutro',feliz:'feliz',triste:'triste',curiosa:'curioso',sonolenta:'sono',irritada:'irritado',assustada:'medo',carinhosa:'afeto',surpresa:'surpresa',tonta:'tonta',entediada:'neutro_deitado',doente:'doente',aliviada:'descansando',desconfiada:'desconfiado',relaxada:'afeicao'};
export const Expressoes={
  mostrar(id){
    const svg=EXPRESSOES[id];
    if(!svg){console.warn('Expressão ainda não reproduzida:',id);return false}
    document.getElementById('nebo').innerHTML=`<svg viewBox="0 0 200 130" role="img" aria-label="${id}">${svg}</svg>`;return true
  },
  doSentimento(s){return this.mostrar(MAPA[s]||'neutro')}
};
