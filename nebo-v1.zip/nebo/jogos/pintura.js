import {Jogos} from './jogos.js';
// PONTO DE EXTENSÃO: implementar o jogo e trocar pronto para true.
Jogos.registrar({id:'pintura',nome:'Pintura',icone:'🎨',pronto:false});
