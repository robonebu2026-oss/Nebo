// Registro de jogos. Para criar um jogo novo, sem mexer em sentimentos:
// Jogos.registrar({id,nome,icone,pronto:true,iniciar(area){ ... Jogos.terminar(id,{pontos,esforco,presente}) }})
import {Eventos} from '../core/eventos.js';import {Armazenamento} from '../core/armazenamento.js';import {Presentes} from '../presentes/presentes.js';
const registro={};
export const Jogos={
  registrar(j){registro[j.id]=j},
  lista:()=>Object.values(registro),
  async terminar(id,{pontos=0,esforco=5,presente}={}){
    const k='recorde:'+id,rec=(await Armazenamento.ler(k))||0;
    if(pontos>rec)await Armazenamento.salvar(k,pontos);
    Eventos.emitir('jogo',{id,pontos,esforco,recorde:Math.max(pontos,rec)});
    if(presente)Presentes.dar(presente);
  }
};
