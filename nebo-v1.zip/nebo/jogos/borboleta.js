import {Jogos} from './jogos.js';
// PONTO DE EXTENSÃO: implementar o jogo e trocar pronto para true.
Jogos.registrar({id:'borboleta',nome:'Borboleta',icone:'🦋',pronto:false});
