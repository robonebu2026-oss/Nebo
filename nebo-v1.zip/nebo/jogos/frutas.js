import {Jogos} from './jogos.js';
// PONTO DE EXTENSÃO: implementar o jogo e trocar pronto para true.
Jogos.registrar({id:'frutas',nome:'Fruit Basket',icone:'🧺',pronto:false});
