import {Jogos} from './jogos.js';
// PONTO DE EXTENSÃO: implementar o jogo e trocar pronto para true.
Jogos.registrar({id:'nebo-run',nome:'Nebo Run',icone:'🏃',pronto:false});
