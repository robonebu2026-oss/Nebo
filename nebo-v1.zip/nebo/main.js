// Só liga os módulos. Nenhuma regra de comportamento mora aqui.
import {Nebo} from './core/nebo.js';
import {Eventos} from './core/eventos.js';
import {Estado} from './core/estado.js';
import {iniciar as iniciarSentimentos} from './core/sentimentos.js';
import {Expressoes} from './visual/expressoes.js';
import {Memoria} from './memoria/memoria.js';
import {Sensores} from './sensores/sensores.js';
import './jogos/nebo-run.js';import './jogos/frutas.js';import './jogos/borboleta.js';import './jogos/pintura.js';
import {iniciar as iniciarUI} from './ui/principal.js';
import {UIEstado} from './ui/estado.js';import {UIBrincar} from './ui/brincar.js';import {UIMundo} from './ui/mundo.js';
import {UIConfig,Config,carregar as carregarConfig} from './ui/configuracoes.js';
(async()=>{
  await Nebo.carregar();await carregarConfig();
  iniciarSentimentos();Memoria.iniciar();Estado.iniciar();iniciarUI();
  Eventos.em('sentimento',({sentimento})=>{
    Expressoes.doSentimento(sentimento);
    if(Config.vibracao&&sentimento!=='neutra')navigator.vibrate?.(20);
  });
  Expressoes.doSentimento(Nebo.estado.saude<30?'doente':'neutra');
  Sensores.iniciar(document.getElementById('nebo'));
  const abas={estado:UIEstado,brincar:UIBrincar,mundo:UIMundo};
  document.querySelectorAll('#barra button').forEach(b=>b.onclick=()=>abas[b.dataset.a].abrir());
  document.getElementById('cfg').onclick=()=>UIConfig.abrir();
})();
