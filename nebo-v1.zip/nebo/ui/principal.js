const $=s=>document.querySelector(s);
export function abrir(titulo,html){$('#pt').textContent=titulo;$('#pc').innerHTML=html;$('#painel').hidden=false}
export const fechar=()=>{$('#painel').hidden=true};
export const iniciar=()=>{$('#fechar').onclick=fechar};
