// Configurações do USUÁRIO (não confundir com preferências da Nebo). Som: só guardado por enquanto (ponto de extensão).
import {abrir} from './principal.js';import {Armazenamento} from '../core/armazenamento.js';import {Sensores} from '../sensores/sensores.js';import {Expressoes,EXPRESSOES} from '../visual/expressoes.js';
export const Config={som:true,vibracao:true,noite:false,sensores:true};
const aplicar=()=>{document.body.classList.toggle('noite',Config.noite);Sensores.ativo=Config.sensores};
export async function carregar(){Object.assign(Config,(await Armazenamento.ler('config'))||{});aplicar()}
const ROT={som:'Sons',vibracao:'Vibração',noite:'Modo noturno',sensores:'Sensores (toque e movimento)'};
export const UIConfig={abrir(){
  abrir('Configurações',Object.keys(ROT).map(k=>`<label class="i">${ROT[k]}<input type="checkbox" data-c="${k}" ${Config[k]?'checked':''}></label>`).join('')
    +`<label class="i">Testar expressão<select id="teste"><option value="">—</option>${Object.keys(EXPRESSOES).map(k=>`<option ${EXPRESSOES[k]?'':'disabled'}>${k}</option>`).join('')}</select></label>`);
  document.querySelectorAll('[data-c]').forEach(i=>i.onchange=()=>{Config[i.dataset.c]=i.checked;Armazenamento.salvar('config',Config);aplicar()});
  document.getElementById('teste').onchange=e=>e.target.value&&Expressoes.mostrar(e.target.value);
}};
