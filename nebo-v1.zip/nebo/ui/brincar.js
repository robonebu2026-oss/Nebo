import {abrir} from './principal.js';import {Jogos} from '../jogos/jogos.js';
export const UIBrincar={abrir(){
  abrir('Brincar',Jogos.lista().map(j=>`<div class="i"><span>${j.icone} ${j.nome}</span><button data-j="${j.id}" ${j.pronto?'':'disabled'}>${j.pronto?'Jogar':'Em breve'}</button></div>`).join(''));
  document.querySelectorAll('[data-j]').forEach(b=>b.onclick=()=>{const j=Jogos.lista().find(x=>x.id===b.dataset.j);j?.pronto&&j.iniciar(document.getElementById('pc'))});
}};
