import {abrir} from './principal.js';import {Nebo} from '../core/nebo.js';
const ROT={energia:'⚡ Energia',fome:'🍎 Fome',saude:'❤️ Saúde',humor:'💗 Humor'};
export const UIEstado={abrir(){abrir('Estado',Object.keys(ROT).map(k=>`<div class="m">${ROT[k]} ${Math.round(Nebo.estado[k])}%<i><b style="width:${Nebo.estado[k]}%"></b></i></div>`).join(''))}};
