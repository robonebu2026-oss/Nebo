import {abrir} from './principal.js';import {Cidade} from '../mundo/cidade.js';
export const UIMundo={abrir(){
  abrir('Nébula City',Cidade.lista().map(l=>`<div class="i"><span>${l.icone} ${l.nome}</span><button data-l="${l.id}" ${l.pronto?'':'disabled'}>${l.pronto?'Visitar':'Em breve'}</button></div>`).join(''));
  document.querySelectorAll('[data-l]').forEach(b=>b.onclick=()=>Cidade.visitar(b.dataset.l));
}};
