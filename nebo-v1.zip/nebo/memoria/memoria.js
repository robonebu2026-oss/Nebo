// Memória = acontecimentos e experiências (não é gosto; isso é preferencias.js).
import {Eventos} from '../core/eventos.js';import {Nebo} from '../core/nebo.js';
const GUARDAR=['alimento','jogo','presente','visita','encontro','descoberta'];
export const Memoria={
  registrar(tipo,dados){Nebo.memoria.push({tipo,dados,t:Date.now()});if(Nebo.memoria.length>300)Nebo.memoria.shift();Nebo.salvar()},
  buscar:tipo=>Nebo.memoria.filter(m=>m.tipo===tipo),
  iniciar(){Eventos.em('*',(t,d)=>GUARDAR.includes(t)&&this.registrar(t,d))}
};
