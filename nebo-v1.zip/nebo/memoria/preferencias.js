// Preferências = gostos da Nebo (>0 gosta, <0 não gosta). Não são configurações do usuário.
import {Nebo} from '../core/nebo.js';
export const Preferencias={
  gosto:item=>Nebo.preferencias[item]||0,
  definir(item,v){Nebo.preferencias[item]=v;Nebo.salvar()},
  aprender(item){/* PONTO DE EXTENSÃO: regra de como repetir uma experiência vira gosto */}
};
