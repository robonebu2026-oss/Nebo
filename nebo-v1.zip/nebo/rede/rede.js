// SÓ ESTRUTURA. Nada online. Ao receber outro Nebo, use Eventos.emitir('encontro',{id,nome,humor,amigo}).
const pendente=n=>()=>{console.info('rede.'+n+': ainda não implementada');return false};
export const Rede={
  entrarSala:pendente('entrarSala'),enviarEstado:pendente('enviarEstado'),aoReceber:pendente('aoReceber'),
  pedirAmizade:pendente('pedirAmizade'),amigos:()=>[],reconhecer:()=>false
};
