import {Eventos} from '../core/eventos.js';import {Nebo} from '../core/nebo.js';
export const CATALOGO={joia:'💎',brinquedo:'🧸',estrela:'🌟'};
export const Presentes={
  dar(tipo){if(!CATALOGO[tipo])return;Nebo.presentes.push({tipo,t:Date.now()});Nebo.salvar();Eventos.emitir('presente',{tipo})},
  lista:()=>Nebo.presentes
};
