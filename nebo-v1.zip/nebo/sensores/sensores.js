// Só emite eventos. PONTOS DE EXTENSÃO: arrastar, inclinar, pinça, caminhada, toque longo (já emite 'toque_longo', sem regra ainda).
import {Eventos} from '../core/eventos.js';
export const Sensores={
  ativo:true,
  iniciar(alvo){
    let n=0,t,inicio=0,ultimo=0;
    alvo.addEventListener('pointerdown',()=>{inicio=Date.now()});
    alvo.addEventListener('pointerup',()=>{
      if(!this.ativo)return;
      if(Date.now()-inicio>600){Eventos.emitir('toque_longo');return}
      n++;clearTimeout(t);
      t=setTimeout(()=>{Eventos.emitir('toque'+Math.min(n,3));n=0},350);
    });
    addEventListener('devicemotion',e=>{
      const a=e.accelerationIncludingGravity;if(!a||!this.ativo)return;
      if(Math.hypot(a.x||0,a.y||0,a.z||0)>28&&Date.now()-ultimo>1500){ultimo=Date.now();Eventos.emitir('chacoalhar')}
    });
  }
};
