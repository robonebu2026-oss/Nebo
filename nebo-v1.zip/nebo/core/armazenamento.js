// Único ponto de leitura/escrita. Para sincronizar depois, troque o motor com Armazenamento.usar(...); os outros módulos não mudam.
const local={
  async ler(k){try{return JSON.parse(localStorage.getItem('nebo:'+k))}catch{return null}},
  async salvar(k,v){try{localStorage.setItem('nebo:'+k,JSON.stringify(v))}catch{}}
};
let motor=local;
export const Armazenamento={ler:k=>motor.ler(k),salvar:(k,v)=>motor.salvar(k,v),usar:m=>{motor=m}};
