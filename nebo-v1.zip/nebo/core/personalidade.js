// Cada personalidade troca certas reações pelo jeito dela. Ajuste as trocas aqui.
export const PERSONALIDADES={
  carinhosa:{feliz:'carinhosa'},
  curiosa:{desconfiada:'curiosa'},
  calma:{irritada:'desconfiada',assustada:'surpresa'},
  brincalhona:{entediada:'curiosa'},
  temperamental:{desconfiada:'irritada',triste:'irritada'},
  reservada:{curiosa:'desconfiada',surpresa:'assustada'}
};
export const modular=(p,s)=>PERSONALIDADES[p]?.[s]??s;
