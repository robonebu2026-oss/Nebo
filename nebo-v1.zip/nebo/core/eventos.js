// Caminho comum de tudo: toque, comida, jogo, sensor, encontro, acontecimentos futuros.
const ouvintes={};
export const Eventos={
  em(tipo,fn){(ouvintes[tipo]??=[]).push(fn)},          // em('*', fn) escuta tudo
  emitir(tipo,dados={}){(ouvintes[tipo]||[]).forEach(f=>f(dados));(ouvintes['*']||[]).forEach(f=>f(tipo,dados))}
};
