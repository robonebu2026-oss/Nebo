// Energia, fome, saúde e humor (0 a 100).
import {Nebo} from './nebo.js';
const lim=v=>Math.max(0,Math.min(100,v));
export const Estado={
  aplicar(d={}){for(const k in d)Nebo.estado[k]=lim((Nebo.estado[k]??0)+d[k]);Nebo.salvar()},
  tique(){const e=Nebo.estado;this.aplicar({energia:-1,fome:-1,...((e.fome<30||e.energia<30)&&{humor:-1}),...(e.fome<=0&&{saude:-1})})},
  iniciar(){setInterval(()=>this.tique(),60000)}
};
