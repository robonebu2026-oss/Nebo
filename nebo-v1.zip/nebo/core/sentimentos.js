// Decide a reação. NÃO desenha nada (isso é visual/expressoes.js).
import {Eventos} from './eventos.js';import {Nebo} from './nebo.js';import {Estado} from './estado.js';
import {modular} from './personalidade.js';import {Preferencias} from '../memoria/preferencias.js';
export const SENTIMENTOS=['neutra','feliz','triste','curiosa','sonolenta','irritada','assustada','carinhosa','surpresa','tonta','entediada','doente','aliviada','desconfiada','relaxada'];
// Cada regra: evento -> {s: sentimento, estado: efeitos}. Novo acontecimento = nova regra aqui.
export const REGRAS={
  toque1:()=>({s:'feliz',estado:{humor:2}}),
  toque2:()=>({s:'curiosa'}),
  toque3:()=>({s:'irritada',estado:{humor:-3}}),
  chacoalhar:()=>({s:'tonta',estado:{energia:-2}}),
  carinho:()=>({s:'carinhosa',estado:{humor:3}}),
  descansar:()=>({s:'relaxada',estado:{energia:15}}),
  alimento:d=>{const g=Preferencias.gosto(d.item);return{s:g>0?'feliz':g<0?'irritada':'aliviada',estado:{fome:Nebo.estado.fome>80?5:25,humor:g*2}}},
  jogo:d=>({s:d.pontos>0?'feliz':'entediada',estado:{humor:3,energia:-(d.esforco??5)}}),
  presente:()=>({s:'surpresa',estado:{humor:4}}),
  visita:d=>({s:d.primeira?'curiosa':'feliz'}),
  encontro:d=>({s:d.amigo?'feliz':'curiosa'})
};
let timer;
const base=()=>Nebo.estado.saude<30?'doente':'neutra';
export function reagir(tipo,dados={}){
  const r=REGRAS[tipo];if(!r)return;
  const x=r(dados);Estado.aplicar(x.estado);
  const s=Nebo.estado.saude<30?'doente':modular(Nebo.personalidade,x.s);
  Nebo.humorAtual=s;Eventos.emitir('sentimento',{sentimento:s,causa:tipo});
  clearTimeout(timer);
  timer=setTimeout(()=>{Nebo.humorAtual=base();Eventos.emitir('sentimento',{sentimento:base(),causa:'calmaria'})},6000);
}
export const iniciar=()=>Eventos.em('*',(t,d)=>reagir(t,d));
