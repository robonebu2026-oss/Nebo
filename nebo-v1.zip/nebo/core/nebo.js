// Identidade da Nebo, separada dos dados da cidade.
import {Armazenamento} from './armazenamento.js';
export const Nebo={
  id:'nebo-'+Math.random().toString(36).slice(2,8),nome:'Nebo',personalidade:'curiosa',humorAtual:'neutra',
  estado:{energia:100,fome:100,saude:100,humor:100},
  memoria:[],preferencias:{},presentes:[],
  async carregar(){const s=await Armazenamento.ler('nebo');if(s)Object.assign(this,s);this.humorAtual='neutra'},
  salvar(){const{carregar,salvar,...dados}=this;return Armazenamento.salvar('nebo',dados)}
};
